#include <stdio.h>
#include <stdlib.h>

typedef struct elem{
    int info;
    struct elem* sx;
    struct elem* dx;
} nodo_albero;

typedef nodo_albero* albero;

// metodi di partenza

int esiste_foglia(albero T, int v);

int altezza(albero T);

int num_nodi_livello(albero T, int l);

// metodi da aggiungere

int esiste_nodo_al_livello(albero T, int v, int l);

int* costruisci_livello_foglia(albero T, int v);

int** livelli_nodo_comune(albero T1, albero T2);

void stampa_nodo_livello(albero T1, albero T2);
