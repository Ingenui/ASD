#include "albero_comune.h"

// metodi di partenza

int esiste_foglia(albero T, int v){
    
    if (T == NULL) return 0;
    else
        if ((T->info == v) && (T->sx == NULL) && (T->dx == NULL))
            return 1;
        else 
            return esiste_foglia(T->sx,v) || esiste_foglia(T->dx,v);

}

int max(int a, int b){
    if (a > b) return a;
    else return b;
}

int altezza(albero T){
    
    if (T == NULL) return -1;
    else
        return 1 + max(altezza(T->sx),altezza(T->dx));
    
}

int num_nodi_livello(albero T, int l){
    if (T == NULL) return 0;
    else
        if (l==0) return 1;
        else return num_nodi_livello(T->sx, l-1) + num_nodi_livello(T->dx, l-1);
}





// metodi di supporto da aggiungere

int livello(albero T, int v){
    int h = altezza(T);
    int i = 0;
    for (i = 0; i<=h; i++)
        if (esiste_nodo_al_livello(T, v, i)) return i;
    return -1;
}

void riempi(int* A, albero T, int l, int* i){
    if (T != NULL){
        if (l == 0) {
            A[*i] = T->info;
            *i = *i + 1;
        }
        else{
            riempi(A, T->sx, l-1,i);
            riempi(A, T->dx, l-1, i);
        }
        
    }
}

void livelli_nodo_comune_aux(albero principale, albero T1, albero T2, int** A, int l){
    if (T1 != NULL){
        if (esiste_nodo_al_livello(T2, T1->info, l)){
            if (A[l] == NULL) {
                int n = num_nodi_livello(principale, l);
                int* B = calloc(n,sizeof(int));
                int i = 0;
                riempi(B, principale, l, &i);
                A[l] = B;
            }
        }
        livelli_nodo_comune_aux(principale, T1->sx, T2, A,l+1);
        livelli_nodo_comune_aux(principale, T1->dx, T2, A,l+1);
    }
    
}

int* costruisci_livello(albero T, int v){
    int* A = NULL;
    int l = livello(T, v);
    int n = num_nodi_livello(T, l);
    printf("livello: %d e num_nodi: %d\n",l,n);
    A = calloc(n,sizeof(int));
    int i = 0;
    riempi(A,T,l,&i);
    return A;
}

// metodi richiesti da aggiungere




int esiste_nodo_al_livello(albero T, int v, int l){
    if (T == NULL) return 0;
    else
        if ((T->info == v) && l == 0) return 1;
        else return esiste_nodo_al_livello(T->sx, v, l-1) || esiste_nodo_al_livello(T->dx, v, l-1);
}

int* costruisci_livello_foglia(albero T, int v){
    int* A = NULL;
    if (esiste_foglia(T, v)){
        A = costruisci_livello(T, v);
    }
    return A;
}



int** livelli_nodo_comune(albero T1, albero T2){
    int** A = NULL;
    int h = altezza(T1);
    A = calloc(h+1,sizeof(int*));
    int i = 0;
    for (i=0; i<=h; i++)
        A[i] = NULL;
    livelli_nodo_comune_aux(T1, T1, T2, A,0);
    return A;
    
}

void stampa_nodo_livello(albero T1, albero T2){
    // lasciato a voi per esercizio
}