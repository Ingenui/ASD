//
//  main.c
//  Esercitazione_7_Nov_2013
//
//  Created by Roberto on 06/11/13.
//  Copyright (c) 2013 Roberto. All rights reserved.
//

#include "intelligenza.h"

int main(int argc, const char * argv[])
{
    int N,K;
    printf("Indicare il numero di giudici: ");
    scanf("%d",&N);
    persona* giudici = creaGiudici(N);
    printf("\nIndicare il numero di candidati: ");
    scanf("%d",&K);
    persona* candidati = creaCandidati(K);
    printf("\n\n");
    int** giudizi = creaGiudizi(N, K);
    stampaGiudizi(giudizi, K, N);
    printf("\n\n");
    candidatoPlus(giudizi, candidati, K, N);
    printf("\n\n");
    giudicePlus(giudizi, giudici, K, N);
    printf("\n\n");
    free(giudici);
    free(candidati);
    free(giudizi);
    return 0;
}

