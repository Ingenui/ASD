/*
In un concorso di intelligenza, N giudici esprimono il loro giudizio su K candidati. Il giudizio è un valore numerico tra 0 e 5.
Un giudice ha associato un codice (numero progressivo tra 1 e N), un nome e un cognome.
Un candidato ha associato un codice (numero progressivo tra 1 e K), un nome e un cognome.
Si scriva un programma in linguaggio C che predi da input N e K:
 
 1) allochi e inizializzi una struttura dati adeguata per la gestione dei giudizi dei giudici sui candidati
 2) data la sequenza (quindi insieme ordinato) di candidati, determini il candidato più intelligente -somma dei voti più grande- (stampando in output nome e cognome)
 3) data la sequenza (quindi insieme ordinato) di giudici, determini il giudice più severo -somma voti più bassa- (stampando in output nome e cognome)
*/


#ifndef Esercitazione_7_Nov_2013_intelligenza_h
#define Esercitazione_7_Nov_2013_intelligenza_h

#include <stdio.h>
#include <stdlib.h>

typedef char string[30];


typedef struct{
    string nome;
    string cognome;
    
} persona;

int** creaGiudizi(int, int);

int sommaVoti(int**, int, int, char);

void stampaPersona(persona*, int);

void candidatoPlus(int**, persona*, int, int);

void giudicePlus(int**, persona*, int, int);


// metodi non richiesti

void stampaGiudizi(int**, int, int);

persona* creaCandidati(int);

persona* creaGiudici(int);

#endif
