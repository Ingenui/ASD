#include "intelligenza.h"


// creo una matrice KxN
int** creaGiudizi(int N, int K){
    int** giudizi = calloc(K,sizeof(int*));
    int i,j;
    
    for (i = 0; i<K; i++)
        giudizi[i] = calloc(N,sizeof(int));
    
    printf("Indicare i giudizi dei giudici per ogni candidato:\n il giudizio deve essere un numero intero compreso tra 0 e 5.\n\n");
    
    for (i = 0; i<K; i++){
        printf("Indica su una riga i %d giudizi del %d° candidato: ",N,i+1);
        for (j = 0; j<N; j++)
            scanf("%d",&giudizi[i][j]);
        printf("\n");
        
    }
    
    
    return giudizi;
}

int sommaVoti(int** giudizi, int i, int X, char flag){
    int j,cont = 0;
    
    switch (flag) {
        case 'c':
            for (j = 0; j < X; j++)
                cont += giudizi[i][j];
            break;
        case 'g':
            for (j = 0; j < X; j++)
                cont += giudizi[j][i];
            break;
            
        default:
            break;
    }
    
    return cont;
}

void stampaPersona(persona persone[], int i){
    printf("Nome: %s\n",persone[i].nome);
    printf("Cognome: %s\n",persone[i].cognome);
}

void candidatoPlus(int** giudizi, persona candidati[], int K, int N){
    int i;
    
    int indCandidato;
    
    int sommaParziale = 0;
    
    int sommaMax = 0;
    
    for (i=0; i<K; i++){
        sommaParziale = sommaVoti(giudizi, i, N, 'c');
        if (sommaParziale > sommaMax){
            sommaMax = sommaParziale;
            indCandidato = i;
        }
    }

    printf("Il candidato con maggiore acume segue: \n");
    stampaPersona(candidati,indCandidato);

}

void giudicePlus(int** giudizi, persona giudici[], int K, int N){

    int i;
    
    int indGiudice;
    
    int sommaParziale = 0;
    
    int sommaMin = 5;
    
    for (i=0; i<N; i++){
        sommaParziale = sommaVoti(giudizi, i, K, 'g');
        if (sommaParziale < sommaMin){
            sommaMin = sommaParziale;
            indGiudice = i;
        }
    }
    
    printf("Il giudice con maggiore zelo segue: \n");
    stampaPersona(giudici,indGiudice);

}



// metodi superflui

void stampaGiudizi(int** giudizi, int K, int N){
    int i,j;
    printf("\nGiudizi:\n");
    for (i = 0; i<K; i++){
        for (j = 0; j<N; j++)
            printf("%d ",giudizi[i][j]);
        printf("\n");
    }
        
}

persona* creaCandidati(int K){
    persona* candidati = calloc(K,sizeof(persona));
    int i;
    for (i=0; i<K; i++){
        printf("Inserisci i dati del %d° candidato:\n",i+1);
        printf("Nome: ");
        scanf("%s",candidati[i].nome);
        printf("Cognome: ");
        scanf("%s",candidati[i].cognome);
        printf("\n");
    }
    return candidati;
}

persona* creaGiudici(int N){
    persona* giudici = calloc(N,sizeof(persona));
    int i;
    for (i=0; i<N; i++){
        printf("Inserisci i dati del %d° giudice:\n",i+1);
        printf("Nome: ");
        scanf("%s",giudici[i].nome);
        printf("Cognome: ");
        scanf("%s",giudici[i].cognome);
        printf("\n");
    }
    return giudici;
}

    
