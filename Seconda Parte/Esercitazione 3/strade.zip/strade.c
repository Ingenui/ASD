//
//  strade.c
//  Homeworks
//
//  Created by Roberto on 09/12/14.
//  Copyright (c) 2014 Roberto. All rights reserved.
//

#include "strade.h"

// metodo che verifica se esiste un cammino da strada1 a strada2.

int raggiungi(stradario T, string strada1, string strada2){
    if (T == NULL) return 0;
    else {
        if (strcmp(T->nome,strada1) == 0)
            return contiene(T->sx,strada2) || contiene(T->dx,strada2);
        else return raggiungi(T->sx,strada1,strada2) || raggiungi(T->dx,strada1,strada2);
    }
}

// metodo che verifica se esiste un cammino tra due nodi che hanno strada come nome.

int loop(stradario T, string strada){
    return raggiungi(T,strada,strada);
}

// metodo che verifica se due stradari sono connessi: almeno la foglia di uno è nodo dell'altro

int Da_A(stradario T1, stradario T2){
    if (T1 == NULL) return 0;
    else {
        if (T1->sx == NULL && T1->dx == NULL) return contiene(T2,T1->nome);
        else return Da_A(T1->sx,T2) || Da_A(T1->dx,T2);
    }
}

int connessi(stradario T1, stradario T2) {
    return Da_A(T1,T2) || Da_A(T2,T1);
}

// metodo di supporto

int contiene(stradario T1, string nome){
    if (T1 == NULL) return 0;
    else {
        if (strcmp(T1->nome,nome) == 0) return 1;
        else return contiene(T1->sx,nome) || contiene(T1->dx,nome);
    }
}

// metodo che verifica se uno stradario è contenuto in un altro

int uguali(stradario T1, stradario T2){
    if (T2 == NULL) return 1;
    if ((T1 != NULL))
        return (strcmp(T1->nome,T2->nome)==0) &&
               uguali(T1->sx,T2->sx) &&
               uguali(T1->dx,T2->dx);
    else {
        return 0;
    }
}

int quartiere(stradario T1, stradario T2){
    if (T1 == NULL) return 0;
    if (T2 == NULL) return 1;
    else {
        if (strcmp(T1->nome, T2->nome) == 0) {
            if (uguali(T1,T2)) return 1;
            else
              return quartiere(T1->sx,T2) || quartiere(T1->dx,T2);
        }
        else {
            return quartiere(T1->sx,T2) || quartiere(T1->dx,T2);
        }
    }
}