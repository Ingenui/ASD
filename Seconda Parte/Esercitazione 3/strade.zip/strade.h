//
//  strade.h
//  Homeworks
//
//  Created by Roberto on 09/12/14.
//  Copyright (c) 2014 Roberto. All rights reserved.
//

#ifndef __Homeworks__strade__
#define __Homeworks__strade__

#include <stdio.h>
#include <string.h>

typedef char string[30];

typedef struct elem2{
    string nome;
    struct elem2* sx;
    struct elem2* dx;
} nodo_strada;

typedef nodo_strada* stradario;

// metodo che verifica se esiste un cammino tra strada1 e strada2.

int raggiungi(stradario T, string strada1, string strada2);

// metodo che verifica se esiste un cammino tra due nodi che hanno strada come nome.

int loop(stradario T, string strada);

// metodo che verifica se due stradari sono connessi: almeno la foglia di uno è nodo dell'altro

int connessi(stradario T1, stradario T2);

// metodo di supporto

int contiene(stradario T1, string nome);

// metodo che verifica se uno stradario è contenuto in un altro

int quartiere(stradario T1, stradario T2);



#endif /* defined(__Homeworks__strade__) */
