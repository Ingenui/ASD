#include <stdio.h>

// a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z

typedef char stringa[30];

void inizializza(int v[]){
     char j='a';
     
     for (j='a'; j != 'z'; j++)
         
         v[j-'a'] = 0;
                 
     v['z'-'a']=0;
    
  }

void set(int v[], stringa st){
     
     inizializza(v);
     
     int i;
     for (i=0; st[i] != '\0'; i++) v[st[i]-'a']++;
     }

int valuta(int v[], char c){
    return v[c-'a'];
}

char occorrenze(stringa st, int v[]){
     set(v,st);
     int max=0; char cmax=st[0];
     int i;
     for (i=0; st[i] != '\0'; i++) 
        if (valuta(v,st[i]) > max) {
                max = valuta(v,st[i]);
                cmax = st[i];
                }
     return cmax;
     }
   
main() {
 int v[26];
 stringa st;
 printf("Fornisci stringa ");
 scanf("%s",st);
 printf("L'occorenza maggiore: %c\n",occorrenze(st,v));
 getch();
       }
