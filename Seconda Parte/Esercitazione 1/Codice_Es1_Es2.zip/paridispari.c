#include <stdio.h>

void paridispari(int* pari, int* dispari){
 int i=10,n;
 while (i>0) {
   scanf("%d",&n);
   if (n%2==0) (*pari)++;
   else (*dispari)++;
   i--;      
 }          
}

void max(int pari, int dispari){
 printf("Numeri pari: %d\n",pari);
 printf("Numeri dispari: %d\n",dispari);
 if (pari > dispari) printf("Sono maggiori i numeri pari\n");
 else
   if (dispari > pari) printf("Sono maggiori i numeri dispari\n");
   else printf("Numeri pari e dispari sono in ugual misura");
}

main(){
 int pari=0,dispari=0;
 printf("Inserisci 10 numeri interi\n");
 paridispari(&pari,&dispari);
 max(pari,dispari);
 getch();      
}
