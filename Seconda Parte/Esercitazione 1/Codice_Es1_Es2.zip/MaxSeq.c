#include <stdio.h>

int MAX(int a, int b) {
  int massimo;
  if (a>b) massimo=a;
   else massimo=b;
  return massimo;
}

int MAXtot() {
  int a, b, i, massimo;
  printf("Inserire un numero: ");
  scanf("%d", &a);
  massimo = a;
  for (i=1; i<10; i++) {
  printf("Inserire un numero: "); 
  scanf("%d", &b);
  massimo = MAX(massimo,b);
  }
  return massimo;
}

main() {
  printf("Il numero massimo inserito e': %d\n", MAXtot());
  getch(); // richiede di digitare un qualsiasi carattere
}
