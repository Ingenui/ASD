#include <stdio.h>

int potenza (int a, int b){
 int ris = 1;
 while (b>0) {
       ris = ris*a;
       b--;
       }
 return ris;       
}       

            
    












int potenzaBIS(int a, int b){
 
 if (b < 1) return 1;
 else {
      b--;
      return a * potenzaBIS(a,b);
      }      
}

main() {
 int a,b;
 printf("Inserire base a e esponente b\n");
 scanf("%d %d",&a,&b);
 int ris = potenza(a,b);
 int ris2 = potenzaBIS(a,b);
 printf("La potenza risultante: %d\n",ris);
 printf("Versione Ricorsiva: %d\n",ris2);
 getch();      
 }
